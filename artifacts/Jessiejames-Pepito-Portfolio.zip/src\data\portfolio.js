// Personal facts, draft skills, projects, and contact links live here.
// Confirm draft skills, project status, and contributions before public submission.
export const personal = {
  name: 'Jessie James Pepito',
  firstName: 'Jessie James',
  lastName: 'Pepito',
  initials: 'JP',
  wordmark: 'jessie',
  role: 'BSIT Student & Aspiring Web Developer',
  location: 'Cebu City, Philippines',
  school: 'Cebu Eastern College',
  degree: 'BS Information Technology',
  introduction: 'I’m an IT student based in Cebu, learning to build practical and user-friendly web applications.',
  heroNote: 'Curiosity first. One project at a time.',
  heroPortrait: '/images/moy.jpg',
  heroPortraitAlt: 'Portrait of Jessie James Pepito',
  portrait: '/images/moy.jpg',
  portraitAlt: 'Portrait of Jessie James Pepito',
  about: [
    'Hi, I’m Jessie — an Information Technology student at Cebu Eastern College, Cebu City, with a growing interest in web development.',
    'Through classwork and personal practice, I’m learning how ideas become useful applications. I enjoy working through problems, making interfaces easier to use, and understanding what happens behind the scenes.',
    'I’m still building my foundations. This portfolio is a place to share what I’m working on and how I’m learning along the way.',
  ],
  learningNote: 'Turning the things I learn into things I can build.',
};

export const navigation = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'skills', label: 'Skills' },
  { id: 'projects', label: 'Projects' },
  { id: 'contact', label: 'Contact' },
];

export const skills = {
  note: 'A growing toolkit. These are draft learning areas, not claims of mastery.',
  groups: [
    {
      id: 'frontend', title: 'Frontend', description: 'Bringing interfaces to life.',
      level: 'Learning & practicing',
      items: ['HTML', 'CSS', 'JavaScript', 'React', 'Tailwind CSS'],
    },
    {
      id: 'backend', title: 'Backend', description: 'Exploring what powers the web.',
      level: 'Learning',
      items: ['Python', 'Django', 'Node.js', 'C# / ASP.NET Core'],
    },
    {
      id: 'tools', title: 'Tools & databases', description: 'Supporting the development process.',
      level: 'Learning & practicing',
      items: ['Git', 'GitHub', 'VS Code', 'MySQL', 'Supabase'],
    },
  ],
};

export const projectCategories = ['All projects', 'Capstone', 'Practice'];

export const projects = [
  {
    id: 'agrilink', number: '01', title: 'AgriLink', category: 'Capstone',
    kind: 'IoT · Agriculture', icon: 'plant',
    description: 'A capstone project exploring IoT environmental monitoring for farmers.',
    technologies: ['IoT', 'Environmental monitoring'],
    contribution: 'Contribution details to be added after confirming my role in the capstone team.',
    status: 'Capstone · Details to confirm',
    overview: 'AgriLink focuses on environmental monitoring in an agricultural setting using IoT. This entry introduces the capstone topic; the specific implementation, features, and outcomes still need to be documented.',
    learning: 'Connecting technology with a practical problem in agriculture.',
    screenshot: null, screenshotAlt: 'AgriLink project screenshot',
    demoUrl: null, sourceUrl: null,
  },
  {
    id: 'lab-monitoring', number: '02', title: 'Computer Laboratory Monitoring System', category: 'Practice',
    kind: 'Web application · Management', icon: 'desktop',
    description: 'A Node.js and MySQL project for managing computers, staff, and incident records.',
    technologies: ['Node.js', 'MySQL'],
    contribution: 'Contribution details to be added after reviewing the project implementation.',
    status: 'Practice project · Details to confirm',
    overview: 'This project explores the management of a computer laboratory, including computer, staff, and incident records. Completed features and implementation details have not yet been confirmed for this portfolio.',
    learning: 'Exploring the relationship between application logic and structured data.',
    screenshot: null, screenshotAlt: 'Computer Laboratory Monitoring System project screenshot',
    demoUrl: null, sourceUrl: null,
  },
  {
    id: 'moldezai', number: '03', title: 'MoldezAI', category: 'Practice',
    kind: 'Web application · AI', icon: 'chat',
    description: 'A Django chatbot practice project with AI API integration and chat history.',
    technologies: ['Python', 'Django', 'AI API'],
    contribution: 'Contribution details to be added after reviewing my practice work.',
    status: 'Practice project · Details to confirm',
    overview: 'MoldezAI is a chatbot practice project built around Django, AI API integration, and chat history. This entry describes the project scope; the completed features and current implementation still need confirmation.',
    learning: 'Learning how a web application can interact with an external API.',
    screenshot: null, screenshotAlt: 'MoldezAI project screenshot',
    demoUrl: null, sourceUrl: null,
  },
];

export const contact = {
  heading: 'Good things start with a hello.',
  introduction: 'Have a question about a project, or just want to connect? I’d be happy to hear from you.',
  email: null, // Your real email address; a mailto link appears automatically.
  github: null, // Your real https://github.com/... URL.
  linkedin: null, // Your real https://www.linkedin.com/in/... URL.
  pendingMessage: 'Contact details coming soon',
};

// Render external links only after a real, safe web URL is supplied.
export function validWebUrl(value) {
  if (!value) return false;
  try { return ['http:', 'https:'].includes(new URL(value).protocol); }
  catch { return false; }
}

export function validEmail(value) {
  return typeof value === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && !/[\r\n]/.test(value);
}
